"""
SQLExecutor — sichere PostgreSQL 16-Ausführung mit Savepoints.

Design-Entscheidungen:
- Eigene DB-Verbindung via SchemaSource.db_alias (nicht Odoo-Cursor!)
- Savepoints statt Cursor-Rollback (ADR-001-REVIEW Befund C1)
- nl2sql_user mit nl2sql_ro-Rolle: DB-seitige Read-Only + Timeout
- statement_timeout auch auf App-Ebene als zusätzliche Absicherung
- EXPLAIN ANALYZE optional für Debug/Admin
- Ergebnis als list[dict] — JSON-serialisierbar, kein pandas-Import nötig
"""

from __future__ import annotations

import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class QueryResult:
    """Ergebnis einer SQL-Ausführung."""

    success: bool
    rows: list[dict[str, Any]] = field(default_factory=list)
    columns: list[dict[str, str]] = field(default_factory=list)
    row_count: int = 0
    truncated: bool = False
    execution_time_ms: float = 0.0
    error: str = ""
    explain: dict | None = None

    def to_dataframe(self):
        """Konvertiert zu pandas DataFrame (optional — benötigt iil-aifw[nl2sql])."""
        try:
            import pandas as pd
            return pd.DataFrame(self.rows)
        except ImportError as exc:
            raise ImportError(
                "pandas ist nicht installiert. "
                "Install: pip install 'iil-aifw[nl2sql]'"
            ) from exc


class SQLExecutor:
    """
    Führt validiertes SQL gegen PostgreSQL 16 aus.

    Nutzt nl2sql_user (IN ROLE nl2sql_ro) für DB-seitige Absicherung.
    Savepoints verhindern Cursor-Rollback der übergeordneten Transaktion.
    """

    def __init__(
        self,
        db_alias: str = "default",
        max_rows: int = 500,
        timeout_seconds: int = 30,
        allow_explain: bool = False,
    ) -> None:
        self._db_alias = db_alias
        self._max_rows = max_rows
        self._timeout_ms = timeout_seconds * 1000
        self._allow_explain = allow_explain

    def execute(self, sql: str) -> QueryResult:
        """
        Führt SQL aus. Niemals Cursor-Rollback der Eltern-Transaktion.

        Raises: NL2SQLExecutionError bei DB-Fehler (nach Savepoint-Rollback).
        """
        from aifw.nl2sql.exceptions import NL2SQLExecutionError
        from django.db import connections

        conn = connections[self._db_alias]
        savepoint_name = f"nl2sql_{uuid.uuid4().hex[:12]}"
        start_time = time.perf_counter()

        with conn.cursor() as cursor:
            cursor.execute(f"SAVEPOINT {savepoint_name}")
            try:
                # App-seitige Timeout-Absicherung (zusätzlich zur DB-Rolle)
                cursor.execute(f"SET LOCAL statement_timeout = {self._timeout_ms}")

                cursor.execute(sql)

                if cursor.description is None:
                    cursor.execute(f"RELEASE SAVEPOINT {savepoint_name}")
                    return QueryResult(success=True, row_count=0)

                columns = [
                    {"name": desc[0], "type_code": str(desc[1])}
                    for desc in cursor.description
                ]
                raw_rows = cursor.fetchall()
                cursor.execute(f"RELEASE SAVEPOINT {savepoint_name}")

            except Exception as exc:
                cursor.execute(f"ROLLBACK TO SAVEPOINT {savepoint_name}")
                error_msg = str(exc)
                logger.warning(
                    "NL2SQL-Execution fehlgeschlagen: %s | SQL: %.200s",
                    error_msg, sql,
                )
                raise NL2SQLExecutionError(error_msg, sql=sql) from exc

        execution_time_ms = (time.perf_counter() - start_time) * 1000

        column_names = [col["name"] for col in columns]
        rows = [
            dict(zip(column_names, self._normalize_row(row)))
            for row in raw_rows
        ]

        truncated = len(rows) >= self._max_rows

        return QueryResult(
            success=True,
            rows=rows,
            columns=columns,
            row_count=len(rows),
            truncated=truncated,
            execution_time_ms=execution_time_ms,
        )

    def explain_analyze(self, sql: str) -> dict:
        """EXPLAIN ANALYZE (nur wenn allow_explain=True)."""
        if not self._allow_explain:
            return {}

        from django.db import connections

        conn = connections[self._db_alias]
        with conn.cursor() as cursor:
            cursor.execute(f"EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON) {sql}")
            result = cursor.fetchone()
            if result:
                plan = result[0][0]
                return {
                    "planning_time_ms": plan.get("Planning Time", 0),
                    "execution_time_ms": plan.get("Execution Time", 0),
                    "rows_estimated": plan.get("Plan", {}).get("Plan Rows", 0),
                    "rows_actual": plan.get("Plan", {}).get("Actual Rows", 0),
                }
        return {}

    @staticmethod
    def _normalize_row(row: tuple) -> list[Any]:
        """Normalisiert DB-native Typen zu JSON-serialisierbaren Python-Typen."""
        import datetime
        import decimal

        result = []
        for val in row:
            if isinstance(val, datetime.datetime):
                result.append(val.isoformat())
            elif isinstance(val, datetime.date):
                result.append(val.isoformat())
            elif isinstance(val, decimal.Decimal):
                result.append(float(val))
            elif isinstance(val, memoryview):
                result.append(None)
            else:
                result.append(val)
        return result
