"""
ResultFormatter — Typen-Normalisierung und Chart-Empfehlung.

Chart-Heuristik basiert auf Spalten-Typen und Datenmenge.
Alle Schwellenwerte sind dokumentiert — kein magisches Verhalten.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

_DATE_KEYWORDS = frozenset({
    "date", "datum", "month", "monat", "week", "woche",
    "year", "jahr", "quarter", "quartal", "created", "updated",
    "angelegt", "geaendert", "time", "zeit", "at",
})

_CATEGORY_KEYWORDS = frozenset({
    "name", "type", "typ", "status", "state", "category", "kategorie",
    "group", "gruppe", "region", "country", "land", "supplier",
    "lieferant", "partner", "code", "nr", "number", "nummer",
})


@dataclass
class ChartRecommendation:
    """Chart-Empfehlung mit expliziter Begründung."""

    chart_type: str          # "table" | "bar" | "line" | "pie" | "gauge" | "hbar"
    x_column: str = ""
    y_columns: list[str] = field(default_factory=list)
    title: str = ""
    reasoning: str = ""      # Explizite Begründung — kein magisches Verhalten


@dataclass
class FormattedResult:
    """Vollständig aufbereitetes Abfrageergebnis."""

    rows: list[dict[str, Any]]
    columns: list[dict[str, str]]
    row_count: int
    truncated: bool
    execution_time_ms: float
    chart: ChartRecommendation
    summary: str


class ResultFormatter:
    """
    Formatiert QueryResult für Frontend-Rendering.

    Chart-Empfehlung-Hierarchie (deterministisch):
      1. 1 Zeile, 1 numerischer Wert → gauge (KPI)
      2. Datum-Spalte + numerische Spalte(n) → line (Zeitreihe)
      3. Kategorische Spalte + 1–2 numerische Spalten, ≤ 20 Zeilen → bar
      4. Kategorische Spalte + 1 numerischer Wert, ≤ 8 Zeilen → pie
      5. Kategorische Spalte + 1 numerischer Wert, > 8 Zeilen → hbar
      6. Alles andere → table
    """

    def format(self, result: "QueryResult") -> FormattedResult:  # noqa: F821
        column_names = [col["name"] for col in result.columns]
        numeric_cols = self._detect_numeric(column_names, result.rows)
        date_cols = [c for c in column_names if any(k in c.lower() for k in _DATE_KEYWORDS)]
        cat_cols = [c for c in column_names if c not in numeric_cols and c not in date_cols]

        chart = self._recommend_chart(
            rows=result.rows,
            numeric_cols=numeric_cols,
            date_cols=date_cols,
            cat_cols=cat_cols,
            column_names=column_names,
        )

        summary = (
            f"{result.row_count} Zeilen (limitiert, weitere vorhanden)"
            if result.truncated
            else f"{result.row_count} Zeilen"
        )
        if result.execution_time_ms > 0:
            summary += f" — {result.execution_time_ms:.0f} ms"

        return FormattedResult(
            rows=result.rows,
            columns=result.columns,
            row_count=result.row_count,
            truncated=result.truncated,
            execution_time_ms=result.execution_time_ms,
            chart=chart,
            summary=summary,
        )

    @staticmethod
    def _recommend_chart(
        rows: list,
        numeric_cols: list[str],
        date_cols: list[str],
        cat_cols: list[str],
        column_names: list[str],
    ) -> ChartRecommendation:
        n_rows = len(rows)

        if n_rows == 1 and len(numeric_cols) == 1 and len(column_names) == 1:
            return ChartRecommendation(
                chart_type="gauge",
                y_columns=numeric_cols,
                title=numeric_cols[0],
                reasoning="Einzelner numerischer Wert → KPI-Anzeige.",
            )

        if date_cols and numeric_cols:
            return ChartRecommendation(
                chart_type="line",
                x_column=date_cols[0],
                y_columns=numeric_cols[:3],
                reasoning=f"Zeitliche Dimension '{date_cols[0]}' + numerische Werte → Liniendiagramm.",
            )

        if cat_cols and numeric_cols and n_rows <= 20:
            return ChartRecommendation(
                chart_type="bar",
                x_column=cat_cols[0],
                y_columns=numeric_cols[:2],
                reasoning=f"Kategorien + numerische Werte, {n_rows} Zeilen ≤ 20 → Balkendiagramm.",
            )

        if cat_cols and len(numeric_cols) == 1 and n_rows <= 8:
            return ChartRecommendation(
                chart_type="pie",
                x_column=cat_cols[0],
                y_columns=numeric_cols,
                reasoning=f"Kategorien + Einzelwert, {n_rows} Zeilen ≤ 8 → Kreisdiagramm.",
            )

        if cat_cols and len(numeric_cols) == 1 and n_rows <= 30:
            return ChartRecommendation(
                chart_type="hbar",
                x_column=numeric_cols[0],
                y_columns=[cat_cols[0]],
                reasoning=f"Kategorien + Einzelwert, {n_rows} Zeilen > 8 → Horizontale Balken.",
            )

        return ChartRecommendation(
            chart_type="table",
            reasoning=(
                f"Keine eindeutige Visualisierung ({n_rows} Zeilen, "
                f"{len(column_names)} Spalten) → Tabelle."
            ),
        )

    @staticmethod
    def _detect_numeric(columns: list[str], rows: list[dict]) -> list[str]:
        """Erkennt numerische Spalten aus den ersten 10 Datensätzen."""
        if not rows:
            return []
        numeric = []
        sample = rows[:10]
        for col in columns:
            values = [row[col] for row in sample if row.get(col) is not None]
            if values and all(isinstance(v, (int, float)) for v in values):
                numeric.append(col)
        return numeric
