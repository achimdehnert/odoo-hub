"""
SQLGenerator — übersetzt natürlichsprachliche Fragen in PostgreSQL-SQL.

Nutzt aifw.sync_completion_with_fallback() — kein asyncio.run(),
gevent-kompatibel, DB-gesteuertes Model-Routing, Budget-Tracking.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass

logger = logging.getLogger(__name__)

_ACTION_CODE = "nl2sql"

_SYSTEM_PROMPT_TEMPLATE = """\
Du bist ein PostgreSQL 16 SQL-Experte. Übersetze natürlichsprachliche Fragen \
in präzises, sicheres SQL.

## Regeln (STRIKT EINZUHALTEN):
1. Gib NUR das SQL-Statement aus — kein Markdown, keine Erklärung, kein Kommentar.
2. Nur SELECT oder WITH ... SELECT — kein INSERT, UPDATE, DELETE, DDL.
3. Kein * — benenne immer alle Spalten explizit.
4. Immer LIMIT {max_rows} am Ende (außer bei Aggregations-Queries ohne sinnvolles LIMIT).
5. Nutze table_alias.column_name bei JOINs um Mehrdeutigkeiten zu vermeiden.
6. Datumswerte: ISO-8601-Format ('2024-01-15'), keine impliziten Casts.
7. Wenn die Frage nicht mit SQL beantwortet werden kann: antworte mit "CANNOT_ANSWER".

## Schema:
{schema_context}

## Konversations-History (letzte {history_length} Fragen):
{history}
"""


@dataclass
class GenerationResult:
    """Ergebnis der SQL-Generierung."""

    success: bool
    sql: str = ""
    raw_response: str = ""
    error: str = ""
    model_used: str = ""
    input_tokens: int = 0
    output_tokens: int = 0


class SQLGenerator:
    """
    Übersetzt natürlichsprachliche Fragen in PostgreSQL-SQL.

    Nutzt aifw.sync_completion_with_fallback() — vollständig synchron,
    kein eigenes HTTP-Handling, kein API-Key-Management.
    """

    def __init__(
        self,
        action_code: str = _ACTION_CODE,
        max_rows: int = 500,
    ) -> None:
        self._action_code = action_code
        self._max_rows = max_rows

    def generate(
        self,
        question: str,
        schema_context: "SchemaContext",  # noqa: F821
        conversation_history: list[dict] | None = None,
        user=None,
        tenant_id=None,
        object_id: str = "",
    ) -> GenerationResult:
        """
        Generiert SQL aus einer natürlichsprachlichen Frage.

        Raises: NL2SQLGenerationError wenn LLM-Call fehlschlägt.
        Returns: GenerationResult (success=False wenn 'CANNOT_ANSWER')
        """
        from aifw import sync_completion_with_fallback
        from aifw.nl2sql.exceptions import NL2SQLGenerationError

        history = conversation_history or []
        history_text = self._format_history(history)
        system_prompt = _SYSTEM_PROMPT_TEMPLATE.format(
            max_rows=self._max_rows,
            schema_context=schema_context.to_prompt_text(),
            history_length=len(history),
            history=history_text,
        )

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": question},
        ]

        result = sync_completion_with_fallback(
            action_code=self._action_code,
            messages=messages,
            temperature=0.1,
            max_tokens=2000,
            user=user,
            tenant_id=tenant_id,
            object_id=object_id or "nl2sql:gen",
            metadata={"question": question, "source": schema_context.source_code},
        )

        if not result.success:
            raise NL2SQLGenerationError(
                f"LLM-Aufruf fehlgeschlagen: {result.error}"
            )

        sql = self._extract_sql(result.content)

        if sql.upper().strip() == "CANNOT_ANSWER":
            return GenerationResult(
                success=False,
                raw_response=result.content,
                error="LLM konnte keine SQL-Antwort generieren (CANNOT_ANSWER).",
                model_used=result.model,
                input_tokens=result.input_tokens,
                output_tokens=result.output_tokens,
            )

        return GenerationResult(
            success=True,
            sql=sql,
            raw_response=result.content,
            model_used=result.model,
            input_tokens=result.input_tokens,
            output_tokens=result.output_tokens,
        )

    @staticmethod
    def _extract_sql(text: str) -> str:
        """Extrahiert SQL aus LLM-Antwort (Markdown-Codeblock oder Plaintext)."""
        text = text.strip()
        match = re.search(r"```(?:sql)?\s*([\s\S]+?)```", text, re.IGNORECASE)
        if match:
            return match.group(1).strip()
        match = re.search(r"\b(SELECT|WITH)\b[\s\S]+", text, re.IGNORECASE)
        if match:
            return match.group(0).strip()
        return text

    @staticmethod
    def _format_history(history: list[dict]) -> str:
        if not history:
            return "(keine vorherigen Fragen)"
        lines = []
        for entry in history[-5:]:
            lines.append(f"  Frage: {entry.get('question', '')}")
            lines.append(f"  SQL:   {entry.get('sql', '')[:200]}")
        return "\n".join(lines)
