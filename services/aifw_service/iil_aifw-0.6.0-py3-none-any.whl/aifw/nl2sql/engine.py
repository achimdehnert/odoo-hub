"""
NL2SQLEngine — High-Level Facade: Frage → SQL → Ergebnis → Chart.

Orchestriert SchemaRegistry, SQLGenerator, SQLValidator, SQLExecutor,
ResultFormatter. Consumer nutzt nur diese Klasse.

Error Handling:
    Alle Fehler werden als NL2SQLResult(success=False, error=...) zurückgegeben.
    Kein Exception-Swallowing — Fehler haben klare Typen und Meldungen.
    NL2SQLError-Subklassen können vom Consumer explizit gefangen werden.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class NL2SQLResult:
    """Vollständiges Ergebnis der NL2SQL-Pipeline."""

    success: bool
    sql: str = ""
    error: str = ""
    error_type: str = ""
    generation: "GenerationResult | None" = None   # noqa: F821
    validation: "ValidationResult | None" = None   # noqa: F821
    query_result: "QueryResult | None" = None       # noqa: F821
    formatted: "FormattedResult | None" = None      # noqa: F821
    warnings: list[str] = field(default_factory=list)


class NL2SQLEngine:
    """
    High-Level Facade für NL2SQL-Pipeline.

    Alle Schritte sind synchron — kein asyncio.run(), gevent-kompatibel.

    Usage::

        engine = NL2SQLEngine(source_code="scm_manufacturing")
        result = engine.ask(
            question="Welcher Lieferant hatte die beste Liefertreue?",
            user=request.user,
            tenant_id=request.user.profile.tenant_id,
        )

        if result.success:
            print(result.sql)
            print(result.formatted.summary)
            print(result.formatted.chart.chart_type)
        else:
            print(result.error_type, result.error)
    """

    def __init__(
        self,
        source_code: str,
        action_code: str = "nl2sql",
        registry: "SchemaRegistry | None" = None,   # noqa: F821
    ) -> None:
        from aifw.nl2sql.executor import SQLExecutor
        from aifw.nl2sql.formatter import ResultFormatter
        from aifw.nl2sql.generator import SQLGenerator
        from aifw.nl2sql.models import SchemaSource
        from aifw.nl2sql.registry import SchemaRegistry
        from aifw.nl2sql.validator import SQLValidator

        self.source_code = source_code

        source = SchemaSource.objects.filter(
            code=source_code, is_active=True
        ).first()

        if not source:
            available = list(
                SchemaSource.objects.filter(is_active=True).values_list("code", flat=True)
            )
            raise ValueError(
                f"SchemaSource '{source_code}' nicht gefunden. "
                f"Verfügbare Codes: {available}"
            )

        self._registry = registry or SchemaRegistry()
        self._generator = SQLGenerator(
            action_code=action_code,
            max_rows=source.max_rows,
        )
        self._validator = SQLValidator(
            blocked_tables=source.get_all_blocked_tables(),
            table_prefix=source.table_prefix,
            max_rows=source.max_rows,
        )
        self._executor = SQLExecutor(
            db_alias=source.db_alias,
            max_rows=source.max_rows,
            timeout_seconds=source.timeout_seconds,
            allow_explain=source.allow_explain,
        )
        self._formatter = ResultFormatter()
        self._source = source

    def ask(
        self,
        question: str,
        user=None,
        tenant_id=None,
        conversation_history: list[dict] | None = None,
    ) -> NL2SQLResult:
        """
        Vollständige NL2SQL-Pipeline: Frage → SQL → Ergebnis → Chart.

        Gibt immer NL2SQLResult zurück — wirft keine Exceptions.
        Fehler sind in NL2SQLResult.error beschrieben.
        """
        from aifw.nl2sql.exceptions import (
            NL2SQLExecutionError,
            NL2SQLGenerationError,
        )

        # ── Schritt 1: Schema-Kontext laden ───────────────────────────────
        try:
            schema_context = self._registry.get_context(self.source_code)
        except Exception as exc:
            return NL2SQLResult(
                success=False,
                error=f"Schema-Fehler: {exc}",
                error_type="NL2SQLSchemaError",
            )

        # ── Schritt 2: SQL generieren ──────────────────────────────────────
        import hashlib
        q_hash = hashlib.sha256(question.encode()).hexdigest()[:12]

        try:
            gen_result = self._generator.generate(
                question=question,
                schema_context=schema_context,
                conversation_history=conversation_history,
                user=user,
                tenant_id=tenant_id,
                object_id=f"nl2sql:gen:{q_hash}",
            )
        except NL2SQLGenerationError as exc:
            return NL2SQLResult(
                success=False,
                error=str(exc),
                error_type="NL2SQLGenerationError",
            )

        if not gen_result.success:
            return NL2SQLResult(
                success=False,
                error=gen_result.error,
                error_type="NL2SQLGenerationError",
                generation=gen_result,
            )

        # ── Schritt 3: SQL validieren ──────────────────────────────────────
        val_result = self._validator.validate(gen_result.sql)
        if not val_result.is_valid:
            logger.warning(
                "NL2SQL-Validierung fehlgeschlagen (Stufe %d): %s | SQL: %.200s",
                val_result.stage, val_result.error, gen_result.sql,
            )
            return NL2SQLResult(
                success=False,
                error=val_result.error,
                error_type="NL2SQLValidationError",
                generation=gen_result,
                validation=val_result,
            )

        # ── Schritt 4: SQL ausführen ───────────────────────────────────────
        try:
            query_result = self._executor.execute(val_result.sanitized_sql)
        except NL2SQLExecutionError as exc:
            return NL2SQLResult(
                success=False,
                error=str(exc),
                error_type="NL2SQLExecutionError",
                generation=gen_result,
                validation=val_result,
            )

        # ── Schritt 5: Formatieren + Chart-Empfehlung ─────────────────────
        formatted = self._formatter.format(query_result)

        return NL2SQLResult(
            success=True,
            sql=val_result.sanitized_sql,
            generation=gen_result,
            validation=val_result,
            query_result=query_result,
            formatted=formatted,
            warnings=val_result.warnings,
        )
