"""
aifw.nl2sql — Natural Language to SQL Extension für iil-aifw.

Übersetzt natürlichsprachliche Fragen (DE/EN) in sicheres PostgreSQL 16 SQL,
führt es aus und formatiert das Ergebnis mit automatischer Chart-Empfehlung.

Installation:
    pip install "iil-aifw[nl2sql]"

Voraussetzungen:
    1. SchemaSource in DB anlegen (manage.py init_nl2sql_schema)
    2. nl2sql_ro PostgreSQL-Rolle anlegen (docker/db/init.sql)
    3. AIActionType(code='nl2sql') konfigurieren (manage.py init_aifw_config)

Schnellstart::

    from aifw.nl2sql import NL2SQLEngine

    engine = NL2SQLEngine(source_code="scm_manufacturing")
    result = engine.ask("Welcher Lieferant hatte die beste Liefertreue?")

    if result.success:
        print(result.sql)
        print(result.formatted.summary)
        print(result.formatted.chart.chart_type)
        df = result.query_result.to_dataframe()
    else:
        print(result.error_type, result.error)
"""

from aifw.nl2sql.engine import NL2SQLEngine, NL2SQLResult
from aifw.nl2sql.exceptions import (
    NL2SQLError,
    NL2SQLExecutionError,
    NL2SQLGenerationError,
    NL2SQLSchemaError,
    NL2SQLValidationError,
)
from aifw.nl2sql.executor import QueryResult
from aifw.nl2sql.formatter import ChartRecommendation, FormattedResult
from aifw.nl2sql.generator import GenerationResult
from aifw.nl2sql.registry import SchemaContext, SchemaRegistry
from aifw.nl2sql.validator import ValidationResult

__all__ = [
    "NL2SQLEngine",
    "NL2SQLResult",
    "NL2SQLError",
    "NL2SQLExecutionError",
    "NL2SQLGenerationError",
    "NL2SQLSchemaError",
    "NL2SQLValidationError",
    "QueryResult",
    "ChartRecommendation",
    "FormattedResult",
    "GenerationResult",
    "SchemaContext",
    "SchemaRegistry",
    "ValidationResult",
]
