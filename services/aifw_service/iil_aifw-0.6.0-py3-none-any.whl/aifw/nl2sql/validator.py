"""
SQLValidator — 3-stufige SQL-Sicherheitsprüfung.

Stufe 1: Strukturelle Prüfung (Regex + einfache Heuristiken)
Stufe 2: Tabellen-Whitelist (sqlglot AST-Analyse)
Stufe 3: LIMIT-Enforcement

Keine DB-Calls — vollständig deterministisch und testbar.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

# Verbotene SQL-Keywords (case-insensitive, als vollständige Wörter)
_BLOCKED_STATEMENTS = re.compile(
    r"\b(INSERT|UPDATE|DELETE|MERGE|REPLACE|UPSERT"
    r"|CREATE|DROP|ALTER|TRUNCATE|RENAME"
    r"|GRANT|REVOKE|DENY"
    r"|COPY|VACUUM|CLUSTER|REINDEX"
    r"|CALL|EXECUTE|DO"
    r"|pg_read_file|pg_write_file|pg_ls_dir|pg_stat_file"
    r"|lo_import|lo_export|lo_create|lo_unlink"
    r"|dblink|file_fdw)\b",
    re.IGNORECASE,
)

_ALLOWED_START = re.compile(r"^\s*(SELECT|WITH)\b", re.IGNORECASE)

# Tabellen/Schemas die immer geblockt sind
_ALWAYS_BLOCKED_PATTERNS = re.compile(
    r"\b(auth_user|auth_token|authtoken_token|django_session"
    r"|aifw_llm_providers|aifw_llm_models|aifw_action_types"
    r"|information_schema|pg_catalog|pg_toast)\b",
    re.IGNORECASE,
)

_LIMIT_RE = re.compile(r"\bLIMIT\s+(\d+)\b", re.IGNORECASE)


@dataclass
class ValidationResult:
    """Ergebnis der SQL-Validierung."""

    is_valid: bool
    sanitized_sql: str = ""
    error: str = ""
    stage: int = 0       # 0=OK, 1=Struktur, 2=Whitelist, 3=Limit-Wrapping
    warnings: list[str] = field(default_factory=list)


class SQLValidator:
    """
    3-stufige SQL-Sicherheitsprüfung.

    Sicherheits-Philosophie:
    - Defense in Depth: Jede Stufe ergänzt die DB-seitige Absicherung
    - Fail-safe defaults: Bei Unsicherheit → ablehnen
    - Keine stillen Korrekturen: Jede Änderung am SQL wird in warnings protokolliert
    - sqlglot für AST-Analyse: Kein fragiles Regex-Parsing von SQL-Struktur
    """

    def __init__(
        self,
        blocked_tables: frozenset[str] | None = None,
        table_prefix: str = "",
        max_rows: int = 500,
    ) -> None:
        self._blocked_tables = blocked_tables or frozenset()
        self._table_prefix = table_prefix
        self._max_rows = max_rows

    def validate(self, sql: str) -> ValidationResult:
        """Führt alle Validierungs-Stufen aus. Gibt ValidationResult zurück."""
        # ── Stufe 1: Strukturelle Prüfung ──────────────────────────────────
        sql = sql.strip().rstrip(";")

        if not _ALLOWED_START.match(sql):
            return ValidationResult(
                is_valid=False,
                error=f"SQL muss mit SELECT oder WITH beginnen. Erhalten: '{sql[:50]}...'",
                stage=1,
            )

        if ";" in sql:
            return ValidationResult(
                is_valid=False,
                error="SQL enthält Semikolon — Statement-Chaining ist nicht erlaubt.",
                stage=1,
            )

        blocked_match = _BLOCKED_STATEMENTS.search(sql)
        if blocked_match:
            return ValidationResult(
                is_valid=False,
                error=f"Verbotenes SQL-Keyword: '{blocked_match.group(0)}'.",
                stage=1,
            )

        always_blocked_match = _ALWAYS_BLOCKED_PATTERNS.search(sql)
        if always_blocked_match:
            return ValidationResult(
                is_valid=False,
                error=f"Zugriff auf gesperrte Tabelle/Schema: '{always_blocked_match.group(0)}'.",
                stage=1,
            )

        # ── Stufe 2: Tabellen-Whitelist (sqlglot AST) ──────────────────────
        table_check = self._check_tables(sql)
        if not table_check.is_valid:
            return table_check

        # ── Stufe 3: LIMIT-Enforcement ─────────────────────────────────────
        sanitized_sql, warnings = self._enforce_limit(sql)

        return ValidationResult(
            is_valid=True,
            sanitized_sql=sanitized_sql,
            stage=0,
            warnings=warnings,
        )

    def _check_tables(self, sql: str) -> ValidationResult:
        """Extrahiert Tabellennamen via sqlglot und prüft gegen Blocklist."""
        try:
            import sqlglot
            import sqlglot.expressions as exp

            parsed = sqlglot.parse_one(sql, dialect="postgres")
            table_names = {
                table.name.lower()
                for table in parsed.find_all(exp.Table)
                if table.name
            }
        except Exception as exc:
            # sqlglot-Parse-Fehler → konservativ ablehnen
            return ValidationResult(
                is_valid=False,
                error=f"SQL konnte nicht geparst werden (sqlglot): {exc}",
                stage=2,
            )

        for table_name in table_names:
            if table_name in self._blocked_tables:
                return ValidationResult(
                    is_valid=False,
                    error=f"Tabelle '{table_name}' ist in der Blocklist.",
                    stage=2,
                )

        return ValidationResult(is_valid=True)

    def _enforce_limit(self, sql: str) -> tuple[str, list[str]]:
        """Stellt sicher dass LIMIT vorhanden und <= max_rows."""
        warnings: list[str] = []
        limit_match = _LIMIT_RE.search(sql)

        if not limit_match:
            sanitized = f"{sql} LIMIT {self._max_rows}"
            warnings.append(
                f"LIMIT fehlte — automatisch LIMIT {self._max_rows} hinzugefügt."
            )
            return sanitized, warnings

        existing_limit = int(limit_match.group(1))
        if existing_limit > self._max_rows:
            sanitized = _LIMIT_RE.sub(f"LIMIT {self._max_rows}", sql)
            warnings.append(
                f"LIMIT {existing_limit} wurde auf {self._max_rows} reduziert."
            )
            return sanitized, warnings

        return sql, warnings
