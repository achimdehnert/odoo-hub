"""
SchemaRegistry — lädt und cached Schema-Metadaten für NL2SQL-Prompts.

Cache-Strategie: TTL-basierter In-Memory-Cache pro process.
Cache-Invalidierung: explizit via invalidate() oder bei SchemaSource-Änderung
(via Django-Signal, analog zu aifw.signals für AIActionType).
"""

from __future__ import annotations

import logging
import threading
import time
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)

_CACHE_LOCK = threading.Lock()
_CACHE: dict[str, "_CacheEntry"] = {}
_DEFAULT_TTL = 300  # 5 Minuten


@dataclass
class ColumnMeta:
    name: str
    data_type: str
    nullable: bool = True
    description: str = ""
    example_values: list[str] = field(default_factory=list)


@dataclass
class TableMeta:
    name: str
    description: str = ""
    domain: str = ""
    columns: list[ColumnMeta] = field(default_factory=list)
    sample_queries: list[str] = field(default_factory=list)
    row_count_hint: Optional[int] = None


@dataclass
class SchemaContext:
    """Vollständiger Schema-Kontext für LLM-Prompt."""

    source_code: str
    tables: list[TableMeta]
    db_alias: str
    table_prefix: str

    def to_prompt_text(self) -> str:
        """Serialisiert Schema als strukturierten Text für LLM-System-Prompt."""
        lines = [
            f"# Datenbank-Schema: {self.source_code}",
            f"# Tabellen-Prefix: {self.table_prefix or 'keine Einschränkung'}",
            "",
        ]
        for table in self.tables:
            lines.append(f"## Tabelle: {table.name}")
            if table.description:
                lines.append(f"Beschreibung: {table.description}")
            if table.domain:
                lines.append(f"Domäne: {table.domain}")
            if table.row_count_hint:
                lines.append(f"Ungefähre Datenmenge: ~{table.row_count_hint:,} Zeilen")
            lines.append("Spalten:")
            for col in table.columns:
                nullable = "NULL" if col.nullable else "NOT NULL"
                ex = (
                    f" (Beispiele: {', '.join(col.example_values[:3])})"
                    if col.example_values
                    else ""
                )
                desc = f" — {col.description}" if col.description else ""
                lines.append(f"  - {col.name} {col.data_type} {nullable}{desc}{ex}")
            if table.sample_queries:
                lines.append("Beispiel-Abfragen:")
                for q in table.sample_queries:
                    lines.append(f"  • {q}")
            lines.append("")
        return "\n".join(lines)


@dataclass
class _CacheEntry:
    context: SchemaContext
    expires_at: float


class SchemaRegistry:
    """
    Lädt SchemaContext aus DB (SchemaSource.schema_xml) mit TTL-Cache.

    Thread-safe. Cache-Invalidierung via invalidate(source_code).
    """

    def __init__(self, ttl: int = _DEFAULT_TTL) -> None:
        self._ttl = ttl

    def get_context(self, source_code: str) -> SchemaContext:
        """Gibt gecachten SchemaContext zurück. Lädt neu wenn Cache abgelaufen."""
        with _CACHE_LOCK:
            entry = _CACHE.get(source_code)
            if entry and entry.expires_at > time.monotonic():
                return entry.context

        context = self._load(source_code)

        with _CACHE_LOCK:
            _CACHE[source_code] = _CacheEntry(
                context=context,
                expires_at=time.monotonic() + self._ttl,
            )
        return context

    def invalidate(self, source_code: str | None = None) -> None:
        """Invalidiert Cache. None = gesamten Cache leeren."""
        with _CACHE_LOCK:
            if source_code is None:
                _CACHE.clear()
            else:
                _CACHE.pop(source_code, None)

    def _load(self, source_code: str) -> SchemaContext:
        from aifw.nl2sql.exceptions import NL2SQLSchemaError
        from aifw.nl2sql.models import SchemaSource

        try:
            source = SchemaSource.objects.filter(
                code=source_code, is_active=True
            ).first()
        except Exception as exc:
            raise NL2SQLSchemaError(
                f"DB-Fehler beim Laden von SchemaSource '{source_code}': {exc}"
            ) from exc

        if not source:
            raise NL2SQLSchemaError(
                f"SchemaSource '{source_code}' nicht gefunden oder inaktiv. "
                f"Bitte 'manage.py init_nl2sql_schema' ausführen."
            )

        tables = self._parse_xml(source.schema_xml) if source.schema_xml else []

        return SchemaContext(
            source_code=source_code,
            tables=tables,
            db_alias=source.db_alias,
            table_prefix=source.table_prefix,
        )

    @staticmethod
    def _parse_xml(xml_text: str) -> list[TableMeta]:
        """Parst Schema-XML in TableMeta-Objekte."""
        try:
            root = ET.fromstring(xml_text)
        except ET.ParseError as exc:
            logger.error("Schema-XML Parse-Fehler: %s", exc)
            return []

        tables: list[TableMeta] = []
        for table_elem in root.findall(".//table"):
            columns = []
            for col_elem in table_elem.findall("column"):
                examples = [e.text for e in col_elem.findall("example") if e.text]
                columns.append(ColumnMeta(
                    name=col_elem.get("name", ""),
                    data_type=col_elem.get("type", "text"),
                    nullable=col_elem.get("nullable", "true").lower() != "false",
                    description=col_elem.findtext("description", ""),
                    example_values=examples,
                ))

            sample_queries = [
                q.text for q in table_elem.findall("sample_query") if q.text
            ]
            row_count_text = table_elem.get("row_count_hint")
            tables.append(TableMeta(
                name=table_elem.get("name", ""),
                description=table_elem.findtext("description", ""),
                domain=table_elem.get("domain", ""),
                columns=columns,
                sample_queries=sample_queries,
                row_count_hint=int(row_count_text) if row_count_text else None,
            ))

        return tables
