"""
Management Command: init_nl2sql_schema

Lädt Schema-XML aus Datei in SchemaSource.schema_xml.
Idempotent: update_or_create — mehrfaches Ausführen ist sicher.

Usage:
    python manage.py init_nl2sql_schema \\
        --code scm_manufacturing \\
        --name "SCM Manufacturing" \\
        --xml-file /path/to/schema_scm_manufacturing.xml \\
        --table-prefix scm_ \\
        --max-rows 500 \\
        --timeout 30
"""

from __future__ import annotations

import sys
from pathlib import Path

from django.core.management.base import BaseCommand, CommandError


class Command(BaseCommand):
    help = "Lädt Schema-XML in SchemaSource (idempotent: update_or_create)."

    def add_arguments(self, parser) -> None:
        parser.add_argument(
            "--code",
            required=True,
            help="Eindeutiger SchemaSource-Code, z.B. 'scm_manufacturing'.",
        )
        parser.add_argument(
            "--name",
            required=True,
            help="Anzeigename der Schema-Quelle.",
        )
        parser.add_argument(
            "--xml-file",
            dest="xml_file",
            required=False,
            default="",
            help="Pfad zur Schema-XML-Datei. Leer = Schema-XML leeren.",
        )
        parser.add_argument(
            "--db-alias",
            dest="db_alias",
            default="default",
            help="Django DATABASES-Alias (Standard: 'default').",
        )
        parser.add_argument(
            "--table-prefix",
            dest="table_prefix",
            default="",
            help="Erlaubter Tabellen-Prefix, z.B. 'scm_'.",
        )
        parser.add_argument(
            "--blocked-tables",
            dest="blocked_tables",
            default="",
            help="Kommaseparierte Liste geblockter Tabellen.",
        )
        parser.add_argument(
            "--max-rows",
            dest="max_rows",
            type=int,
            default=500,
            help="Maximale Ergebniszeilen (Standard: 500).",
        )
        parser.add_argument(
            "--timeout",
            dest="timeout_seconds",
            type=int,
            default=30,
            help="Query-Timeout in Sekunden (Standard: 30).",
        )
        parser.add_argument(
            "--allow-explain",
            dest="allow_explain",
            action="store_true",
            default=False,
            help="EXPLAIN ANALYZE erlauben (Standard: nein).",
        )

    def handle(self, *args, **options) -> None:
        from aifw.nl2sql.models import SchemaSource

        code = options["code"]
        xml_file = options.get("xml_file", "")
        schema_xml = ""

        if xml_file:
            xml_path = Path(xml_file)
            if not xml_path.exists():
                raise CommandError(f"XML-Datei nicht gefunden: {xml_path}")
            try:
                schema_xml = xml_path.read_text(encoding="utf-8")
                self.stdout.write(f"  XML geladen: {xml_path} ({len(schema_xml)} Zeichen)")
            except OSError as exc:
                raise CommandError(f"XML-Datei nicht lesbar: {exc}") from exc

        defaults = {
            "name": options["name"],
            "db_alias": options["db_alias"],
            "schema_xml": schema_xml,
            "table_prefix": options["table_prefix"],
            "blocked_tables": options["blocked_tables"],
            "max_rows": options["max_rows"],
            "timeout_seconds": options["timeout_seconds"],
            "allow_explain": options["allow_explain"],
            "is_active": True,
        }

        source, created = SchemaSource.objects.update_or_create(
            code=code,
            defaults=defaults,
        )

        action = "angelegt" if created else "aktualisiert"
        self.stdout.write(
            self.style.SUCCESS(
                f"SchemaSource '{code}' ({source.name}) {action}.\n"
                f"  DB-Alias:      {source.db_alias}\n"
                f"  Tabellen-Prefix: '{source.table_prefix or 'keiner'}'\n"
                f"  Max Zeilen:    {source.max_rows}\n"
                f"  Timeout:       {source.timeout_seconds}s\n"
                f"  Schema-XML:    {len(source.schema_xml)} Zeichen\n"
            )
        )
        self.stdout.write(
            "  Nächster Schritt: AIActionType(code='nl2sql') konfigurieren:\n"
            "    python manage.py init_aifw_config\n"
        )
