"""
Management Command: nl2sql_stats

Zeigt Performance-Report aus pg_stat_statements für NL2SQL-Queries.
Erfordert: PostgreSQL 16 + CREATE EXTENSION pg_stat_statements in der DB.

Usage:
    python manage.py nl2sql_stats
    python manage.py nl2sql_stats --top 20 --min-calls 3 --db-alias default
"""

from __future__ import annotations

from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "NL2SQL Performance-Report aus pg_stat_statements."

    def add_arguments(self, parser) -> None:
        parser.add_argument(
            "--top",
            type=int,
            default=10,
            help="Anzahl der langsamsten Queries (Standard: 10).",
        )
        parser.add_argument(
            "--min-calls",
            dest="min_calls",
            type=int,
            default=1,
            help="Mindestanzahl Aufrufe (Standard: 1).",
        )
        parser.add_argument(
            "--db-alias",
            dest="db_alias",
            default="default",
            help="Django DATABASES-Alias (Standard: 'default').",
        )

    def handle(self, *args, **options) -> None:
        from django.db import connections

        db_alias = options["db_alias"]
        top = options["top"]
        min_calls = options["min_calls"]

        conn = connections[db_alias]

        # Prüfe ob pg_stat_statements verfügbar ist
        with conn.cursor() as cursor:
            try:
                cursor.execute(
                    "SELECT 1 FROM pg_extension WHERE extname = 'pg_stat_statements'"
                )
                if not cursor.fetchone():
                    self.stderr.write(
                        self.style.WARNING(
                            "pg_stat_statements ist nicht installiert.\n"
                            "Aktivieren: CREATE EXTENSION pg_stat_statements;\n"
                            "Und in postgresql.conf: shared_preload_libraries = 'pg_stat_statements'"
                        )
                    )
                    return
            except Exception as exc:
                self.stderr.write(self.style.ERROR(f"DB-Fehler: {exc}"))
                return

            # Holt die langsamsten Queries — gefiltert nach Queries die
            # typischerweise von nl2sql_user ausgeführt werden.
            # Hinweis: userid-Filter benötigt pg_stat_statements.track_utility=on
            # und kennt den nl2sql_user OID. Alternativ: alle Queries, sortiert nach mean_exec_time.
            cursor.execute(
                """
                SELECT
                    left(query, 120)                              AS query_preview,
                    calls,
                    round(mean_exec_time::numeric, 1)             AS mean_ms,
                    round(total_exec_time::numeric, 1)            AS total_ms,
                    round((rows::numeric / NULLIF(calls, 0)), 1)  AS avg_rows,
                    round(stddev_exec_time::numeric, 1)           AS stddev_ms
                FROM pg_stat_statements
                WHERE calls >= %s
                  AND query ILIKE 'SELECT%%'
                ORDER BY mean_exec_time DESC
                LIMIT %s
                """,
                [min_calls, top],
            )
            rows = cursor.fetchall()

        if not rows:
            self.stdout.write("Keine Queries gefunden (min_calls=%d)." % min_calls)
            return

        self.stdout.write(
            self.style.HTTP_INFO(
                f"\nTop {top} langsamste SELECT-Queries "
                f"(min {min_calls} Aufrufe) — DB: {db_alias}\n"
            )
        )

        header = f"{'#':>4}  {'Mean ms':>9}  {'Calls':>6}  {'Total ms':>10}  {'Avg Rows':>9}  {'StdDev':>8}  Query"
        self.stdout.write(header)
        self.stdout.write("-" * len(header))

        for i, (query, calls, mean_ms, total_ms, avg_rows, stddev_ms) in enumerate(rows, 1):
            query_short = query.replace("\n", " ").strip()
            self.stdout.write(
                f"{i:>4}  {mean_ms:>9}  {calls:>6}  {total_ms:>10}  "
                f"{avg_rows:>9}  {stddev_ms:>8}  {query_short}"
            )

        self.stdout.write(
            "\nTipp: Queries mit mean_ms > 1000 und 0 Index-Scans benötigen einen Index.\n"
            "      EXPLAIN ANALYZE via NL2SQLEngine(allow_explain=True) verfügbar.\n"
        )
