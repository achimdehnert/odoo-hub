"""SchemaSource — DB-gesteuertes Schema-Routing für NL2SQL."""

from django.db import models


class SchemaSource(models.Model):
    """
    Konfiguriert eine NL2SQL-Datenquelle.

    Eine SchemaSource definiert:
    - welche DB-Verbindung genutzt wird (db_alias)
    - welche Tabellen abgefragt werden dürfen (table_prefix, blocked_tables)
    - wie das Schema dem LLM präsentiert wird (schema_xml)
    - Sicherheits- und Performance-Grenzen (max_rows, timeout_seconds)

    DB-getrieben: Alle Parameter ohne Code-Änderung via Django Admin konfigurierbar.
    """

    code = models.CharField(
        max_length=100,
        unique=True,
        help_text="Eindeutiger Identifier, z.B. 'scm_manufacturing'.",
    )
    name = models.CharField(max_length=200)
    db_alias = models.CharField(
        max_length=100,
        default="default",
        help_text="Django DATABASES-Alias. 'default' für Haupt-DB.",
    )
    schema_xml = models.TextField(
        blank=True,
        help_text=(
            "Schema-Metadaten als XML. Beschreibt Tabellen, Spalten, "
            "Beziehungen und Few-Shot-Beispiele für den LLM-Prompt."
        ),
    )
    table_prefix = models.CharField(
        max_length=50,
        blank=True,
        help_text=(
            "Erlaubter Tabellen-Prefix (z.B. 'scm_'). "
            "Leer = alle Tabellen erlaubt (dann blocked_tables nutzen)."
        ),
    )
    blocked_tables = models.TextField(
        blank=True,
        default="",
        help_text=(
            "Kommaseparierte Tabellennamen die nie abgefragt werden dürfen. "
            "Intern werden auth_user, auth_token, django_session etc. immer ergänzt."
        ),
    )
    max_rows = models.IntegerField(
        default=500,
        help_text="Maximale Ergebniszeilen. Höhere LIMIT-Werte werden auf diesen Wert reduziert.",
    )
    timeout_seconds = models.IntegerField(
        default=30,
        help_text="Query-Timeout in Sekunden. Zusätzlich zur DB-seitigen nl2sql_ro-Konfiguration.",
    )
    allow_explain = models.BooleanField(
        default=False,
        help_text="EXPLAIN ANALYZE für Debug-Zwecke erlauben (nur für Manager).",
    )
    is_active = models.BooleanField(default=True)

    # Intern immer geblockte Tabellen — unabhängig von blocked_tables-Konfiguration.
    _ALWAYS_BLOCKED: tuple[str, ...] = (
        "auth_user",
        "auth_password",
        "auth_token",
        "authtoken_token",
        "aifw_llm_providers",
        "aifw_llm_models",
        "aifw_action_types",
        "django_session",
        "django_migrations",
    )

    class Meta:
        app_label = "aifw"
        db_table = "aifw_nl2sql_schema_sources"
        verbose_name = "NL2SQL Schema Source"
        verbose_name_plural = "NL2SQL Schema Sources"
        ordering = ["code"]

    def __str__(self) -> str:
        return f"{self.code} ({self.name})"

    def get_all_blocked_tables(self) -> frozenset[str]:
        """Liefert vollständige Blocklist: konfigurierte + intern immer geblockte."""
        configured = (
            {t.strip() for t in self.blocked_tables.split(",") if t.strip()}
            if self.blocked_tables
            else set()
        )
        return frozenset(configured) | frozenset(self._ALWAYS_BLOCKED)
