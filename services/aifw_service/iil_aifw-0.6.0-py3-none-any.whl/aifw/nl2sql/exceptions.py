"""NL2SQL Fehler-Hierarchie.

Alle Fehler sind deterministisch — kein magisches Verhalten, keine stillen
Fallbacks. Consumer muss jeden Fehlertyp explizit behandeln.
"""


class NL2SQLError(Exception):
    """Basis-Exception für alle NL2SQL-Fehler."""


class NL2SQLGenerationError(NL2SQLError):
    """LLM hat kein SQL generiert oder API-Fehler."""


class NL2SQLValidationError(NL2SQLError):
    """SQL hat Validierung nicht bestanden (Stufe 1–3)."""

    def __init__(self, message: str, stage: int, sql: str = "") -> None:
        super().__init__(message)
        self.stage = stage   # 1=Struktur, 2=Whitelist, 3=Limit
        self.sql = sql


class NL2SQLExecutionError(NL2SQLError):
    """SQL-Ausführung fehlgeschlagen (Timeout, PG-Fehler)."""

    def __init__(self, message: str, sql: str = "") -> None:
        super().__init__(message)
        self.sql = sql


class NL2SQLSchemaError(NL2SQLError):
    """Schema-Source nicht gefunden oder nicht aktiv."""
